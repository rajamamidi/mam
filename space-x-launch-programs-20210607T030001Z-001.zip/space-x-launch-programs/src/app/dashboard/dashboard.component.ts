import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CommonServiceService } from 'src/services/common-service.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  launchList: any = [];
  model: any = {};

  constructor(private commonService: CommonServiceService,
    private f: NgForm) { }

  ngOnInit(): void {
    this.getAllData();
  }

  filter() {
    if (this.model?.filterYear) {
      this.getYearSuccessData(this.model?.filterYear);
    } else if (this.model?.filterLaunch) {
      this.getLaunchSuccessData(this.model?.filterLaunch);
    } else if (this.model?.filterLand) {
      this.getLandSuccessData(this.model?.filterLand);
    }
  }

  clearFilter() {
    this.model = {};
    this.f.reset();
    this.getAllData();
  }

  getAllData() {
    this.commonService.getAllData().subscribe((data) => {
      this.launchList = data;
    }, (error) => {
      console.log('all-error', error);
    });
  }

  getYearSuccessData(year:any) {
    this.commonService.getYearSuccessData(year).subscribe((data) => {
      let yearFilteredData:any = data;
      if (yearFilteredData?.length == 0) {
        this.launchList = yearFilteredData.filter((x: any) => x.launch_year == this.model.filterYear);
      } else {
        this.launchList = data;
      }
    }, (error) => {
      console.log('year-error', error);
    });
  }

  getLaunchSuccessData(launch:any) {
    this.commonService.getLaunchSuccessData(launch).subscribe((data) => {
      let launchFilteredData:any = data;
      if (launchFilteredData?.length == 0) {
        this.launchList = launchFilteredData.filter((x: any) => x.launch_year == this.model.filterLaunch);
      } else {
        this.launchList = data;
      }
    }, (error) => {
      console.log('launch-error', error);
    });
  }

  getLandSuccessData(land:any) {
    this.commonService.getLandSuccessData(land).subscribe((data) => {
      let landFilteredData:any = data;
      if (landFilteredData?.length == 0) {
        this.launchList = landFilteredData.filter((x: any) => x.launch_year == this.model.filterLand);
      } else {
        this.launchList = data;
      }
    }, (error) => {
      console.log('land-error', error);
    });
  }

}
