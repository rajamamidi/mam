import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonServiceService {

  baseURL: any;

  constructor(private http: HttpClient) { 
    this.baseURL = environment.baseURL;
  }

  getAllData() {
    let api = this.baseURL;
    return this.http.get(api);
  }

  getYearSuccessData(year:any) {
    let api = this.baseURL+"&launch_year='"+ year +"' ";
    return this.http.get(api);
  }

  getLaunchSuccessData(launch:any) {
    let api = this.baseURL+"&launch_success="+ launch +" ";
    return this.http.get(api);
  }

  getLandSuccessData(land:any) {
    let api = this.baseURL+"&land_success="+ land +" ";
    return this.http.get(api);
  }

}
